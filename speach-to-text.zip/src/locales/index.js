// src/locales/index.js
export { fa } from './fa.js';
export { en } from './en.js';
export { ar } from './ar.js';
export { tr } from './tr.js';